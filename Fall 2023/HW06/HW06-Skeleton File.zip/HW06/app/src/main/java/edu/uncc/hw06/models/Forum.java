package edu.uncc.hw06.models;

import java.io.Serializable;

public class Forum implements Serializable {
}
